<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DestinationFile extends Model
{
    //
    protected $table = 'pm_destination_file';
    public $timestamps = false;

}
